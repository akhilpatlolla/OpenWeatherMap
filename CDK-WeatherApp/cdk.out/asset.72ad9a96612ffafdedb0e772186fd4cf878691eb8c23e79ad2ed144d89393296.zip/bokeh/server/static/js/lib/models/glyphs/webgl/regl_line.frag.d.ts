declare const shader: string;
export default shader;
