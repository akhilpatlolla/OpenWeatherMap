export declare function gcd(values: number[]): number;
export declare function is_pow_2(v: number): boolean;
//# sourceMappingURL=math.d.ts.map