.. rubric:: Details

{% if sampledata %}:Sampledata: {{ sampledata }}{% endif %}
{% if apis %}:Bokeh APIs: {{ apis }}{% endif %}
{% if refs %}:More info: {{ refs }}{% endif %}
{% if keywords %}:Keywords: {{ keywords }}{% endif %}
