import "./index";
//# sourceMappingURL=main.d.ts.map