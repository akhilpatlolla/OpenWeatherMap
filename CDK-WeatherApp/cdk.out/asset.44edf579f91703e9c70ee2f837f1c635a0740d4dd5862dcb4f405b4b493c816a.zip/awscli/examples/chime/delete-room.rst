**To delete a chat room**

The following ``delete-room`` example deletes the specified chat room and removes the chat room memberships. ::

    aws chime delete-room \
        --account-id 12a3456b-7c89-012d-3456-78901e23fg45 \
        --room-id abcd1e2d-3e45-6789-01f2-3g45h67i890j

This command produces no output.

For more information, see `Creating a Chat Room <https://docs.aws.amazon.com/chime/latest/ug/chime-chat-room.html>`__ in the *Amazon Chime User Guide*.