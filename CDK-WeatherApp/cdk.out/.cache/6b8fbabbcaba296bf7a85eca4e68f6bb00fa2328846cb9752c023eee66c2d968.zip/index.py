# import pandas as pd
# import requests
import matplotlib.pyplot as plt

def handler():
    pass